# resource-scheduler
Calender based scheduler for sharing a resource, like a shared test device in a lab. React js based SPA UI and golang based REST API backend.
